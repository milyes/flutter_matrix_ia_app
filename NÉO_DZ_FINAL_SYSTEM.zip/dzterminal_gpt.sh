#!/bin/bash
echo 'GPT connecté... (extrait)'