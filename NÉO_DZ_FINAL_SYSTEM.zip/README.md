
# 🧠 NÉO_DZ – Système IA Final

Pack complet : Terminal IA + HTML + GPT + FX + README

## Fichiers :
- index.html : interface Web IA
- dzterminal_fx.sh : terminal avec effets Matrix
- dzterminal_gpt.sh : connecté à GPT-4o
- config_gpt.sh : pour ta clé API OpenAI

## Utilisation :
source config_gpt.sh
bash dzterminal_gpt.sh
ou
bash dzterminal_fx.sh

Créé pour la Matrice DZ – Ilyes Zoubirou.
