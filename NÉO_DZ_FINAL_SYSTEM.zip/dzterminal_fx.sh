#!/bin/bash
echo 'Effets FX activés... (extrait)'